<?php
session_start();
session_destroy();
$result = 'logout';
echo $result;
?>