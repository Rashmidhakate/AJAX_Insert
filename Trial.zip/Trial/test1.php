<?php
/*  create function as a swapvlaue and swap vlaue $a and $b with  each other wihtout third veriable. 
* 
*/
?>
<?php
$a = 10;
$b = 20;
list($a, $b) = array($b, $a);
echo $a."</br>"; // answer $a=20
echo $b; // $b=10
?>
<?php 
/*

The list() function is used to assign values to a list of variables. Like array(), this is not really a function, but a language construct. list() is used to assign a list of variables in one operation.
For example:
*/
?>
<?php
$w3r1_array = array("php","javascript","asp");
list($x, $y, $z) = $w3r1_array; // $x= php ,$y=javascript ,$z=asp
echo "We have covered $x,  $y and $z.";  //output : We have covered php, javascript and asp
$w3r2_array = array("php","javascript","asp");
list($x, , $z) = $w3r2_array;
echo "We have covered $x and $z and so many other topics"; //output: We have covered php and asp and so many other topics
?>


