<html>
	<head>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>	
	</head>
	<body>
		<div>
			<form action="#" method="post" id="login_form" name="login_form" >
				username:<input type="text" id="username" name="username" />
				password:<input type="password" id="password" name="password" />
				<input type="submit" name="submit" value="submit" onclick= "return do_login()" />
			</form>
			<p id="loading_spinner">Please fill data</p>
		</div>
	</body>
</html>	
<style>
	#loading_spinner
	{
		display:none;
	}
</style>
<script type="text/javascript">
	function do_login(){
		var username = $('#username').val();
		var password = $('#password').val();
		if(username!='' && password!=''){
			$("#loading_spinner").css({"display":"none"});

			$.ajax({
				type:'POST',
				dataType: "json",
				url:'login.php',
				data:{username:username,password:password},
				success:function(response){
					if(response.result=="success")
					{
						console.log("success");
						window.location.href="form.php";
					}
					else{
						alert('invalid credentials');
					}
				}
			});
		}
		else{
			$("#loading_spinner").css({"display":"block","background-color": "yellow"});
		}
		return false;
	}
</script>