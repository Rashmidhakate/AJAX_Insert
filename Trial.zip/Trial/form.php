<html>
	<head>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	</head>
	<body>
		<?php
		session_start();
		if(isset($_SESSION['username']))
		{
		?>
			<h2>Hi, <?php echo $_SESSION['username']; ?></h2>
		<?php
		}
		?>
		<form method="post" id="logout_form" name="logout_form">
			<input type="submit" name="logout" value="Logout" onclick="return do_logout()" />
		</form>

		<div style="position:center;width:80%;border:1px solid;margin:61px;">
			<form method="post" id="contact_form" name="contact_form" enctype="multipart/form-data">
				Contact Name:<input type="text" name="contact_name" id="contact_name" /></br>
				Address:<textarea  name="address" id="address" ></textarea> </br>
				Email:<input type="email" name="email" id="email" /></br>
				Phone:<input type="text" name="phone" id="phone" /></br>
				Avatar:<input type="file" name="image" id="image" /></br>
				<input type="submit" id="contact" name="contact" value="Contact US" />
			</form>
		</div>
	</body>
</html>

<script type="text/javascript">
	function do_logout(){
		$.ajax({
			type:'POST',
			url:'logout.php',
			success:function(response){
				if(response == "logout")
				{
					console.log("logout");
					window.location.href="test2.php";
				}
			}
		});
		return false;
	}
	
	$(document).ready(function(){
		$('#contact_form').submit(function(e){
			//alert("hello");
			e.preventDefault();
			$.ajax({
				url : "insert.php",
				type: "POST",
				data: new FormData(this),
				processData: false,
				contentType: false,
				success: function () {
					alert('form was submitted');
					$('#contact_form')[0].reset();
				}
			});
		});
		$("#image").change(function() {
			var file = this.files[0];
			var imagefile = file.type;
			var match= ["image/jpeg","image/png","image/jpg"];
			if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2]))){
			    alert('Please select a valid image file (JPEG/JPG/PNG).');
			    $("#image").val('');
			    return false;
			}
		});
	});


</script>