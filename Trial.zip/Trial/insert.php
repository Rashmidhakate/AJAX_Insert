<?php 
include("connection.php");
$todate = date('Y-m-d H:i:s');
$contact_name=$_POST['contact_name'];
$address=$_POST['address'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$image=$_FILES["image"]["name"];

if($_FILES["image"]["name"]){
	$name = $_FILES["image"]["name"];
	$size = $_FILES["image"]["size"];
	$ext = end(explode(".", $name));
	$allowed_ext = array("png", "jpg", "jpeg");
	if(in_array($ext, $allowed_ext))
	{
		if($size < (1024*1024))
		{
		}
	}
}

$query= "insert into contact_form(contact_name,address,email,phone,image,created_at,updated_at) value ('".$contact_name."','".$address."','".$email."','".$phone."','".$image."','".$todate."','".$todate."')";
$select_data = mysqli_query($conn,$query);

if($select_data){
	//upload image in folder
	move_uploaded_file($_FILES['image']['tmp_name'],"Image/".$_FILES['image']['name']);

	/* mail script*/ 
	$email_subject = "New Form submission";

	// To send HTML mail, the Content-type header must be set
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	//$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

	// Compose a simple HTML email message
	$message = '<html><body>';
	$message .= '<h1>'."Hello $contact_name".'</h1>';
	$message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
	$message .= '<tr style="background: #eee;"><td><strong>Name:</strong> </td><td>'.$contact_name.'</td></tr>';
	$message .= '<tr style="background: #eee;"><td><strong>Address:</strong> </td><td>'.$address.'</td></tr>';
	$message .= '<tr style="background: #eee;"><td><strong>Email:</strong> </td><td>'.$email.'</td></tr>';
	$message .= '<tr style="background: #eee;"><td><strong>Phone no.:</strong> </td><td>'.$phone.'</td></tr>';
	$message .= '<tr style="background: #eee;"><td><strong>Image:</strong> </td><td>';

	//send image from localhost in mail using base64
	$image = 'Image/'.$image;
	// Read image path, convert to base64 encoding
	$imageData = base64_encode(file_get_contents($image));
	// Format the image SRC:  data:{mime};base64,{data};
	$src = 'data: '.mime_content_type($image).';base64,'.$imageData;
	$message .= '<img src="'.$src.'" alt=""  width="100" height="100" />';
	$message .= '</td></tr>';
	$message .= '</table>';
	$message .= '</body></html>';
	//mail(to,subject,message,headers)
	mail($email,$email_subject,$message,$headers);

	/***/
	$result = 'success';
}
else{
	$result = 'failed';
}
echo $result;
?>