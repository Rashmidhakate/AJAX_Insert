<?php 
include("connection.php");
session_start();
$username=$_POST['username'];
$password=$_POST['password'];
$query= "select * from login where username='$username' and password='$password'";
$select_data = mysqli_query($conn,$query);
$result = array();
if($row = mysqli_fetch_array($select_data) ){
	$_SESSION['username']=$_POST['username'];
	$result['result'] = 'success';
}
else{
	$result['result'] = 'failed';
}
echo json_encode($result);
?>